import React from 'react';
import Likes from './Components/Likes/Likes';
import Navbar from './Components/Navbar/Navbar';
import {Routes,Route} from "react-router-dom";
import FormPage from './Components/FormPage/FormPage';
const App = () => {
  return (
    <div>
      <Navbar/>
      <Routes>
        <Route path="/" element={<Likes/>} />
        <Route path="/FormPage" element={<FormPage/>} />
      </Routes>
      
    </div>
  )
}

export default App