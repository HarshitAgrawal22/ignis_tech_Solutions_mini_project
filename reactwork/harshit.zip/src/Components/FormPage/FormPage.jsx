import React from 'react'

const FormPage = () => {
  return (
    <form action="/addlikes" method='post'>
        <label htmlFor="heading">Heading: </label>
        <input type="text" name='heading' id='heading' />

        <label htmlFor="date-time"></label>
        <input type="text" name="date-time" id="date-time" />

        <label htmlFor="starts"></label>
        <input type="text" name='starts' id='starts' />
    </form>

  )
}

export default FormPage;